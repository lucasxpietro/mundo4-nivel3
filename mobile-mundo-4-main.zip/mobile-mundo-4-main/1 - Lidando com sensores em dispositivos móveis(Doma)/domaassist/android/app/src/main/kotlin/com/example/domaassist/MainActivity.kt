package com.example.domaassist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
