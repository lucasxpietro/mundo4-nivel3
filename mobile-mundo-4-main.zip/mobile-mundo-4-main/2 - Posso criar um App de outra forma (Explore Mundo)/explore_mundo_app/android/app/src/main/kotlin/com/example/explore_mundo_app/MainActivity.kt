package com.example.explore_mundo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
